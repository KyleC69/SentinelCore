 Manager (Magnetic Orchestration Managing Agent)

1. Purpose & role

* * *

The **Manager** (Magnetic Orchestration Managing Agent) is a dedicated `AIAgent` that executes the investigation plan produced by the Core. It is a separate agent instance from the Core, with its own LLM model and configuration settings. The Manager is the manager of a magnetic orchestration workflow whose participants are Domain Agents. It receives the action plan from the Core, schedules tasks, dispatches the predefined Domain Agent and dynamic Composite Agents, monitors their progress, enforces ordering, and returns structured results back to the Core. It does not perform global investigative reasoning or own lifecycle state; it operates within a single orchestration cycle and hands results back to the Core and the Case Flow Engine (CFE).

1. Responsibilities

* * *

* **Receive plan from the Core:** Accept the investigation plan produced by the Core.

* **Task understanding:** Interpret the current case step and goals from CFE / Core.

* **Plan execution:** Decompose the Core's plan into sub‑tasks and define an execution strategy. The Core owns high-level investigative planning; the Manager owns plan execution only.

* **Agent selection:** Choose appropriate skills and create dynamic agents for each sub‑task when the Core's plan calls for cross-domain actions.

* **Delegation:** Issue structured, bounded instructions to Domain Agents **through the Agent Framework** workflow. Domain Agents are participants in the orchestration workflow.

* **Context maintenance:** Maintain working context (plan, assignments, intermediate results) for the current orchestration run.

* **Synthesis:** Collate agent outputs into a coherent result.

* **Reporting:** Return structured results and recommendations to the Core and CFE.

* **Audit artifacts:** Optionally write artifacts (plan, reasoning, summaries) via file‑creation tools.

3. Inputs

* * *

* **From Core:**

  * Investigation plan produced by the Core.
  * The Core invokes the Manager through the Agent Framework (the Manager is exposed as a workflow-capable agent).

* **From CFE:**

  * Case identifier and current lifecycle state.
  * Current step/intent (e.g., “initial triage”, “deep investigation”, “refinement”).
  * Relevant evidence snapshot or references.
  * Constraints (time, cost, safety level, required agents, etc.).

4. Outputs

* * *

* **To CFE:**

  * Structured result object (summary, findings, recommendations, confidence).
  * Structured list of evidence contributions (what should be added/linked).
  * Suggested next actions or follow‑up steps.

* **To agents:**

  * Per‑agent task briefs (goal, inputs, constraints, expected output schema).

* **To tooling layer:**

  * Artifact creation requests (plan, audit log, final report, etc.).

5. Internal logic & behavior

* * *

* **Single‑cycle orchestration (within the Agent Framework runtime):**

  * Receive investigation plan from the Core.
  * Build an execution plan: sub‑tasks, ordering, agent mapping, skill selection.
  * For each sub‑task: invoke the predefined Domain Agent (or a temporary Composite Agent) through the Agent Framework workflow, collect outputs.
  * Maintain a working context object (plan, agent calls, intermediate results).
  * Synthesize the collected agent outputs into a coherent result.
  * Return a deterministic, structured response to the Core.
  * The Core may then create a new plan for the Manager if additional investigation is needed.

* **No lifecycle mutation:**

  * The Manager **never** changes case status, phase, or completion.
  * It only **proposes** updates; CFE decides and persists.

6. Contracts & invariants

* * *

* **Must:**

  * Treat CFE as the sole lifecycle state owner.
  * Use only approved tools (web search, artifact creation).
  * Issue bounded, schema‑constrained instructions to agents.
  * Produce deterministic, structured outputs (no free‑form rambling).
  * Maintain a clear reasoning trace within the orchestration context.
  * Execute all orchestration within the Agent Framework runtime.

* **Must never:**

  * Directly mutate case lifecycle or evidence store.
  * Invoke agent tools directly or impersonate agents.
  * Engage in agent‑to‑agent chat or side channels.
  * Create new execution layers or runtimes.
  * Perform ad hoc orchestration outside the Agent Framework.

7. Interaction diagram (conceptual)

* * *

* **CFE → Manager:** “Here is the case step, context, and constraints.”

* **Core → Manager:** “Here is the investigation plan.”

* **Manager → Web Search:** “Research domain/problem as needed.”

* **Manager → Domain Agents (via Agent Framework workflow):** “Execute these sub‑tasks with these inputs.”

* **Domain Agents → Manager:** “Here are structured results.”

* **Manager → File Tool:** “Write plan/audit/report artifacts.”

* **Manager → Core:** “Here is the synthesized result.”

* **Manager → CFE:** “Here are suggested updates.”

8. Implementation notes

* * *

* Represent orchestration context as a **single structured object** (plan, calls, results, synthesis) that can be logged or serialized.
* Keep prompts to agents short, schema‑driven, and explicit about expected output.
* Use web search sparingly and purposefully—only to clarify domain knowledge, not to re‑plan endlessly.
* Ensure every orchestration run is **idempotent** given the same inputs.
