

* * *

⭐ Components we will generate docs for
======================================

Here is the full list of SentinelCore components that need documentation:

### **A. Case Flow Engine**

* Case lifecycle
* State machine
* Transition rules
* Evidence accumulation
* Completion criteria

### **B. Manager (Magnetic Orchestration Managing Agent)**

* Receives investigation plan from the Core
* Executes the plan as an Agent Framework workflow
* Domain Agent dispatch and monitoring
* Tool invocation rules
* Returns structured results to the Core

### **C. Preset Domain Agents-SKILLS**

* Fixed‑role agents
* Domain‑specific responsibilities
* Input/output contracts
* Failure handling

### **D. Dynamic Agents**

* On‑demand agent creation
* Role assignment
* Lifespan rules
* Disposal rules

### **E. Tooling Layer**

* Tool registry
* Tool invocation protocol
* Error handling
* Idempotency rules

### **F. Memory & Evidence Layer**

* Short‑term memory
* Long‑term memory
* Evidence grounding
* Retrieval rules
* Consistency guarantees

### **G. Safety Rails**

* Anti‑hallucination rules
* Grounding requirements
* Ambiguity detection
* Refusal conditions

---
