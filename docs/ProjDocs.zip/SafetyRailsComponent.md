

* * *

G. Safety rails
===============

1. Purpose & role

-----------------

Safety Rails are the **cross‑cutting constraints** that keep all LLM‑driven components within acceptable behavior: policy, security, privacy, and operational safety.

1. Responsibilities

-------------------

* **Policy enforcement:** Ensure outputs and tool calls comply with safety policies.

* **Guardrails:** Constrain prompts, tools, and responses.

* **Monitoring:** Detect unsafe patterns or drift.

* **Intervention:** Block, redact, or reshape unsafe actions or outputs.

3. Inputs

---------

* **From Core/Manager/Agents:**

  * Planned tool calls, prompts, and responses.

* **From CFE:**

  * Case‑level safety requirements (e.g., sensitivity level).

4. Outputs

----------

* **To Core/Manager/Agents:**

  * Approved or modified prompts/tool calls.
  * Block decisions with reasons.

* **To CFE/Logs:**

  * Safety events and violations.

5. Internal logic & behavior

----------------------------

* Inspect prompts, tool invocations, and outputs against safety rules.

* Apply transformations (redaction, truncation, rephrasing) when allowed.

* Block operations when necessary and return structured errors.

* Log safety‑relevant events.

6. Contracts & invariants

-------------------------

* **Must:**

  * Be applied consistently across Core, Manager, and agents.
  * Prefer minimal intervention that still satisfies policy.
  * Be transparent in logs about what was blocked or changed.

* **Must never:**

  * Silently alter semantics in a way that misleads CFE or user.
  * Bypass policy for convenience.
  * Perform orchestration or state mutation.

7. Interaction diagram (conceptual)

-----------------------------------

* **Core/Manager/Agent → Safety Rails:** “Here is a planned prompt/tool call/output.”

* **Safety Rails → Core/Manager/Agent:** “Approved/modified/blocked with reason.”

* **Safety Rails → Logs:** “Record safety event.”

8. Implementation notes

-----------------------

* Implement as a **layer**, not a one‑off check—ideally integrated into the Agent Framework.
* Keep rules explicit and testable.
* Provide clear error codes and messages so the Manager can react deterministically.

* * *

If you want, next step can be to pick one of these (e.g., Manager or Safety Rails) and deepen it into a full, code‑adjacent spec with example schemas and message shapes.
