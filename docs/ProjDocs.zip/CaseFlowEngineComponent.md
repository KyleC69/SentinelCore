### Case flow engine – technical specification

* * *

1. Purpose and role

-------------------

**Purpose:**
The Case Flow Engine (CFE) is the stateful controller that governs the lifecycle of a “case” in SentinelCore—from creation through investigation, refinement, and resolution.

**Role in the system:**

* **Single source of truth** for case state and progression.
* **Owner of the case lifecycle**: defines and enforces allowed states and transitions.
* **Coordinator of work**: requests actions from the Core/Manager agent pair but never performs reasoning itself.
* **Guardrail for scope**: prevents uncontrolled branching, looping, or state drift.

The CFE is _not_ an agent and does _not_ call LLMs directly. It is a deterministic state machine that manages the case state.

* * *

1. Responsibilities

-------------------

**Primary responsibilities:**

* **Define and enforce case lifecycle states** (e.g., `New`, `Intake`, `Analysis`, `Investigation`, `Synthesis`, `Review`, `Resolved`, `Aborted`).
* **Manage transitions** between states based on explicit conditions and events.
* **Accumulate and track evidence** and artifacts associated with a case.
* **Emit orchestration requests** to the Core/Manager agent pair when a state requires agent work.
* **Record outcomes** of orchestrated work and update case state accordingly.
* **Expose a stable API** for creating, querying, and mutating cases.

**Explicit non‑responsibilities:**

* No LLM calls.
* No tool invocation.
* No domain reasoning.
* No agent selection.
* No business logic beyond lifecycle rules.

* * *

1. Inputs

---------

**Core inputs:**

* **Case creation request**

  * `case_id` (generated or provided)
  * `initial_prompt` / `problem_description`
  * `metadata` (user, source, priority, tags)

* **Events from Manager (via Core)**

  * `WorkCompleted(case_id, work_item_id, result, evidence_refs, status)`
  * `WorkFailed(case_id, work_item_id, error, recoverable_flag)`
  * `EscalationRequested(case_id, reason)`

* **User/system commands**

  * `AdvanceCase(case_id, target_state?)`
  * `AbortCase(case_id, reason)`
  * `AddEvidence(case_id, evidence_ref, type, source)`
  * `AnnotateCase(case_id, note)`

* **Configuration**

  * Lifecycle definition (states, transitions)
  * Transition rules and guards
  * Timeouts / SLA thresholds (optional)

* * *

1. Outputs

----------

**To Core/Manager:**

* `RequestWork(case_id, work_item_spec)`
  Where `work_item_spec` includes:
  * `required_capability` (e.g., “log_analysis”, “root_cause_hypothesis”)
  * `input_context` (evidence refs, case summary, constraints)
  * `priority`
  * `expected_artifacts` (e.g., “hypothesis_list”, “timeline”, “mitigation_plan")

**To storage / persistence:**

* Case records (state, timestamps, metadata)
* Evidence index (by case, type, source)
* Transition history (audit log)

**To external callers (API/UI):**

* Case snapshot:
  * `case_id`
  * `current_state`
  * `history`
  * `evidence_summary`
  * `open_work_items`
  * `completion_status`

* * *

1. Internal logic

-----------------

### 5.1 State model (example)

You can refine names, but structurally:

* `New`
* `Intake`
* `Scoping`
* `Analysis`
* `Investigation`
* `Synthesis`
* `Review`
* `Resolved`
* `Aborted`

### 5.2 Transition rules (examples)

* `New → Intake`

  * Trigger: `CaseCreated`
  * Guard: `initial_prompt` present

* `Intake → Scoping`

  * Trigger: `WorkCompleted` (intake summary)
  * Guard: required intake artifacts present

* `Scoping → Analysis`

  * Trigger: `AdvanceCase` or auto when scoping artifacts complete
  * Guard: at least one scoped objective defined

* `Analysis → Investigation`

  * Trigger: hypotheses generated
  * Guard: non‑empty hypothesis set

* `Investigation → Synthesis`

  * Trigger: investigation work items completed
  * Guard: evidence attached to at least one hypothesis

* `Synthesis → Review`

  * Trigger: synthesis artifacts created (findings, root cause, recommendations)

* `Review → Resolved`

  * Trigger: user/system approval

* Any → `Aborted`

  * Trigger: `AbortCase`
  * Guard: none (but logged with reason)

### 5.3 Failure handling

* If `WorkFailed` and `recoverable_flag = true`:

  * Option A: retry work item (with backoff / limit)
  * Option B: transition to `Analysis` or `Scoping` with a “needs clarification” flag

* If `WorkFailed` and `recoverable_flag = false`:

  * Transition to `Aborted` or `Review` with failure reason

### 5.4 Rails and constraints

* No state transition without explicit rule.
* No implicit loops—loops must be modeled as explicit transitions (e.g., `Investigation → Analysis`).
* No direct state mutation from agents or Manager—only via CFE logic.
* All transitions logged with:
  * `from_state`, `to_state`, `reason`, `actor`, `timestamp`.

* * *

1. Contracts

------------

**Preconditions:**

* `CaseCreated`:
  * `initial_prompt` must be non‑empty.
* `AdvanceCase`:
  * `case_id` must exist.
  * Target state (if provided) must be reachable from current state.

**Postconditions:**

* After any transition:
  * `current_state` is valid and in lifecycle definition.
  * Transition is recorded in history.
  * Any required orchestration requests are emitted (or explicitly skipped).

**Invariants:**

* A case is in exactly one state at any time.
* A case cannot re‑enter `New`.
* `Resolved` and `Aborted` are terminal states.
* Evidence is always associated with a valid `case_id`.
* Manager cannot change case state directly.

* * *

1. Interaction diagram (logical)

--------------------------------

**Primary flows:**

1. **Case creation**

   * Caller → CFE: `CreateCase`
   * CFE: create record, set state `New → Intake`
   * CFE → Core/Manager: `RequestWork` (intake summary)

2. **Work completion**

   * Manager → CFE: `WorkCompleted`
   * CFE: attach evidence, evaluate transition rules
   * CFE: possibly emit new `RequestWork` or advance state

3. **User‑driven advancement**

   * UI/API → CFE: `AdvanceCase`
   * CFE: validate, transition, possibly emit `RequestWork`

4. **Abort**

   * UI/API → CFE: `AbortCase`
   * CFE: set state `Aborted`, log reason

* * *

1. Implementation notes

-----------------------

**Language/stack assumptions (you can adapt):**

* Implement as a **pure service/module** (e.g., C# class library or service) with:
  * Explicit state machine (enum + transition table or state pattern)
  * Persistence abstraction (repository or event store)
  * Message contracts for Core/Manager interaction

**Determinism:**

* No randomness in transitions.
* Given the same history and inputs, the same state must result.

**Performance:**

* Case state transitions are low‑frequency compared to agent/tool calls—optimize for clarity and auditability over micro‑performance.

**Security:**

* Only trusted system components may call transition APIs.
* User‑initiated transitions must be validated against permissions and allowed states.

* * *

If this structure looks right to you, next we can do the **Manager** with the same level of precision and align its contracts directly against this Case Flow Engine spec.
