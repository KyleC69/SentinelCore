F. Memory & evidence layer

1. Purpose & role

* * *

The Memory & Evidence Layer is the **durable record** of what has been observed, inferred, and decided about a case. It backs the CFE’s lifecycle decisions and provides context to the Core, Manager, and agents.

1. Responsibilities

* * *

* **Evidence storage:** Persist structured evidence items.

* **Retrieval:** Provide relevant evidence slices to CFE, Core, and Manager.

* **Indexing:** Support efficient search and filtering.

* **Auditability:** Maintain a traceable history of what was added, when, and why.

3. Inputs

* * *

* **From CFE:**

  * Evidence items to persist.
  * Links between evidence and case transitions.

* **From Manager (indirectly via CFE):**

  * Suggested evidence contributions.

4. Outputs

* * *

* **To CFE:**

  * Evidence views for lifecycle decisions.

* **To Core/Manager:**

  * Read‑only evidence snapshots or summaries for planning and delegation.

5. Internal logic & behavior

* * *

* Store evidence as structured objects with metadata (source, time, provenance).

* Support queries by case, type, time, and tags.

* Maintain immutability of historical evidence (append‑only or versioned).

* Provide summarized views when requested.

6. Contracts & invariants

* * *

* **Must:**

  * Treat evidence as durable and auditable.
  * Preserve provenance and timestamps.
  * Support deterministic retrieval.

* **Must never:**

  * Perform orchestration or reasoning.
  * Modify evidence without trace.
  * Allow agents to write directly (writes go through CFE).

7. Interaction diagram (conceptual)

* * *

* **CFE → Memory:** “Persist this evidence item for case X.”

* **Memory → CFE:** “Evidence stored; here is ID.”

* **CFE/Core/Manager → Memory:** “Retrieve evidence for case X with filters.”

* **Memory → CFE/Core/Manager:** “Here is the evidence view.”

8. Implementation notes

* * *

* Design evidence schemas to be **LLM‑friendly** (clear fields, minimal ambiguity).
* Support both raw artifacts (e.g., log blobs) and structured interpretations.
* Consider separate indices for retrieval vs. archival.
