D. Dynamic agents

1. Purpose & role

* * *

Dynamic agents are **on‑demand, task‑specific workers** created by the Manager when a task in the Core's plan requires combined cross-domain skills that don’t fit a single preset Domain Agent. They allow flexible specialization without expanding the preset catalog endlessly.

1. Responsibilities

* * *

* **Task specialization:** Focus on a narrow, temporary role defined by the Manager for a cross-domain task from the Core's plan.

* **Contextual reasoning:** Use provided context to perform nuanced analysis or synthesis.

* **Output structuring:** Return results in a schema defined at creation time.

* **Lifecycle:** Exist only for the duration of the orchestration run or step.

3. Inputs

* * *

* **From Manager:**

  * Dynamic role definition (what this agent is “about”).
  * Task description and constraints.
  * Context bundle (relevant snippets, prior results).
  * Expected output schema.

4. Outputs

* * *

* **To Manager:**

  * Structured result object tailored to the dynamic role.
  * Optional suggestions for further analysis or evidence.

5. Internal logic & behavior

* * *

* Interpret the dynamic role and task.

* Use only the tools explicitly allowed by the Manager for this agent (often none, or a narrow subset).

* Perform focused reasoning within the provided context.

* Return schema‑compliant results.

6. Contracts & invariants

* * *

* **Must:**

  * Be fully defined and bounded by the Manager.
  * Respect the output schema and constraints.
  * Treat all context as read‑only.

* **Must never:**

  * Persist state or create long‑lived memory.
  * Call other agents or orchestrate.
  * Mutate case lifecycle or evidence.

7. Interaction diagram (conceptual)

* * *

* **Manager → Dynamic Agent:** “You are a temporary specialist for X; here is context and schema.”

* **Dynamic Agent → Manager:** “Here is the structured result for X.”

8. Implementation notes

* * *

* Use dynamic agents for **shape‑changing** tasks (e.g., summarization, comparison, narrative building) rather than domain tool execution.
* Keep their prompts extremely explicit about boundaries and outputs.
* Treat them as disposable—no reliance on continuity.
